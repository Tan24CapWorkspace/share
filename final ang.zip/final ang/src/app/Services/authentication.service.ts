import { Injectable, OnInit } from '@angular/core'

@Injectable({
  providedIn: 'root'
})
export class AuthenticationService implements OnInit {

  ngOnInit(): void {
    
  }

  public status: boolean
  constructor() { }


  isUserLoggedIn() {
    if (sessionStorage.length != 0) {
      this.status = true
    }
    else {
      return false
    }
  }

  logout() {
    sessionStorage.clear()
  }

}

