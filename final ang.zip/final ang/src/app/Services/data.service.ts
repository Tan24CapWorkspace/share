import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import {Admin} from '../admin/admin.component'
import {Merchant} from '../merch/merch.component'
import { User1 } from '../user1/user.component';

@Injectable({
  providedIn: 'root'
})
export class DataService {

  constructor(private http:HttpClient) { }

  retrieveAdmin(username,password){
    return this.http.get<Admin>(`http://localhost:5000/find/admin/${username}/${password}`)
  }

  retrieveCustomer(username,password){
    return this.http.get<User1>(`http://localhost:5000/find/customer/${username}/${password}`)
  }

  retrieveMerchant(username,password){
    return this.http.get<Merchant>(`http://localhost:5000/find/merchant/${username}/${password}`)
  }

  saveCoupon(Coupon){
    return this.http.post(`http://localhost:5000/coupon/new`,Coupon)
  }

}
