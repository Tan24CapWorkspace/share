import { Component } from "@angular/core";
import { ProductService } from "../Services/productService";
import { Product } from "../models/product";

@Component({
    selector: "show",
    templateUrl: "show.component.html"
})
export class Showcomponent{

    constructor(private service: ProductService){
        this.getProducts();
    }   
    

    products: Product[]=[];
    productsLength: number;
    
    getProducts(){
        this.service.getProducts().subscribe(
            res=>{
                console.log("here")
                this.products = res;
                this.productsLength = this.products.length;
                console.log(this.productsLength/3);
                console.log(this.products)
            }
        )
    }

    showProduct(i){
        let productId = this.products[i].productID
        alert("id is : " + productId)
        this.service.displayProduct(productId) 

    }
}