import { Component, OnInit } from '@angular/core';

export class Admin{
  constructor(
    public adminId:number=0,
    public firstName:string="",
    public lastName:string="",
    public emailid:string="",
    public password:string="",
    public photo:string=""
  ){}
}


@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
